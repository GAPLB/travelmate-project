package com.travelmate.travelmate_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelmateBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
